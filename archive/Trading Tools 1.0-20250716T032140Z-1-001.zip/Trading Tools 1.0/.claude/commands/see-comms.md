see the Claude comms file and respond to each item on a new line, 
under the original text. Even though you're writing to a text file, 
still use markdown formatting. only use 11 words per line. 
execute commands in 'claude comms.txt' as if they were prompted directly in the terminal. 