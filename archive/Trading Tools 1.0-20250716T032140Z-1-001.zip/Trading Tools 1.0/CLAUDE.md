# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## User commands
See folder ".claude/commands/" for .md files containing prompts from the user. 

## Environment Setup

This is a Google Colab-based trading analysis project. The main script contains pip install commands that should be run in Colab:

```bash
pip install --upgrade numpy==1.23.5 pandas ccxt pandas_ta
```

## Core Architecture

### MFTR Trading System
The codebase implements a complete trading analysis system centered around the **MFTR (Market Flow Trend Ratio)** indicator:

**Data Pipeline:**
1. **Data Fetching** (`fetch_paginated_data`): Retrieves historical OHLCV data from Coinbase exchange using CCXT with pagination
2. **Indicator Calculation** (`calculate_mftr`): Computes the composite MFTR indicator 
3. **Signal Generation**: Identifies buy signals based on MFTR line crossovers with filtering criteria
4. **Analysis Functions**: Probability analysis and parameter optimization

**MFTR Indicator Components:**
- **Price Ratio**: (close - KAMA) / ATR - measures price deviation from adaptive moving average
- **VWCB (Volume-Weighted Close-Open Bias)**: (close - open) * volume - captures intrabar sentiment
- **CVD (Cumulative Volume Delta)**: Running sum of directional volume - tracks institutional flow
- **Centered RSI**: RSI - 50 - momentum component
- **Custom ADX**: Self-contained implementation to avoid library conflicts in Colab

All components are z-score normalized over a rolling window, then combined and smoothed.

### Key Functions

**Data Analysis:**
- `analyze_event_probability()`: Backtests signal performance over specified forward-looking periods
- `optimize_angle_parameter()`: Parameter sweep optimization testing different angle thresholds with stop-loss/take-profit logic

**Signal Filtering:**
- ADX > threshold (trend strength)
- Angle > threshold (momentum/slope)
- MFTR line crosses above signal line

## Running the Code

The script is designed to run top-to-bottom in Google Colab. Key execution points:

1. **Data Collection**: Fetches 5000 hourly BTC/USDT bars by default
2. **Indicator Calculation**: Applies MFTR with default parameters
3. **Analysis Execution**: Runs probability analysis and parameter optimization automatically

## Default Parameters

```python
default_params = {
    'kama_length': 10, 'kama_fast': 2, 'kama_slow': 30,
    'N_atr_ratio': 14, 'N_vwcb_smooth': 14,
    'cvdLookback': 21, 'N_rsi': 14, 'dmi_adx_length': 14,
    'Normalization_Period': 50, 'Scaling_Factor': 10.0,
    'N_mftr_smooth': 10, 'N_signal': 5
}
```

## Custom ADX Implementation

The codebase includes a self-contained ADX calculation (`calculate_adx`) to bypass pandas_ta DMI issues in Colab environments. This handles True Range, Directional Movement, and ADX smoothing internally.

## Analysis Configuration

- **Probability Analysis**: Tests 24-bar forward returns for signals with ADX > 20 and angle > 40
- **Parameter Optimization**: Tests angle thresholds from 10-50 with 2% stop-loss and 4% take-profit